<?php
session_start();
$conexion= mysqli_connect(
    'localhost',
    'root',
    '',
    'registrodb'
);

// if (isset($conexion)){
//     echo "conectada";
// }
?>