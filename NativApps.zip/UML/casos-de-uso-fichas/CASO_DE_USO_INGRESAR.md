

| Caso 05  |
|--------|
| LOGUEARSE Y CERRAR SESION  |

| Autores  |
|--------|
| KELVIN MARTINEZ, LIVAN TORRES, MARIO CARRILLO, DAYANA RODIGUEZ |

| Actores |
|---------|
| Sistema, Usuario. |

| Descripción. |
|--------|
| El usuario accederá al sistema de información y posteriormente de hacer los cambios cerrará sesión.   |

| Precondición. |
|--------|
| El usuario debe estar registrado en la base de datos, debe acceder al sitio web del sotware, por tanto debe tener un navegador y conexion a internet. |

| Secuencia Normal. |
|--------|
| 
1.	Ingresar cedula y contraseña en el formulario.
2.	Verificar campos vacíos.
3.	Comprobar que los datos ingresados sean iguales a los de la base de datos.
4.	Dar acceso al software.
5.	Presionar "cerrar sesión".
6.	Destruir la sesión actual y sacar al usuario del software.

 

| Secuencia Alternativa |
|--------|
| 
1.	
2. Campos vacíos o credenciales.
3. Datos no encontrados en la base de datos. 
4. 
5.	 
6.	


| Postcondición |
|--------|
|El usuario accede correctamente al software y posterior a realizar cambios cierra sesión. |

----------
OJO! MODIFICAR IMAGEN
![CASO_DE_USO_01-REGISTRAR_EQUIPO](https://github.com/MERZIOX/NativApps/blob/master/UML/casos-de-usos-diagramas/CASO_DE_USO_01-REGISTRAR_EQUIPO.jpeg?raw=true "CASO DE USO 01-REGISTRAR EQUIPO")
